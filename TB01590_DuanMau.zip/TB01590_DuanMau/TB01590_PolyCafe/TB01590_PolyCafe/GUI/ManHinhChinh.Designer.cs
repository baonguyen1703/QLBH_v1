﻿namespace GUI
{
    partial class ManHinhChinh
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label2 = new Label();
            pictureBox1 = new PictureBox();
            button10 = new Button();
            button9 = new Button();
            btnQuanLyTaiKhoan = new Button();
            button7 = new Button();
            button6 = new Button();
            button5 = new Button();
            btnDoiMatKhau = new Button();
            button3 = new Button();
            button2 = new Button();
            label1 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Times New Roman", 30F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(67, 79);
            label2.Name = "label2";
            label2.Size = new Size(196, 45);
            label2.TabIndex = 36;
            label2.Text = "Poly Cafe'";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.coffee;
            pictureBox1.Location = new Point(44, 177);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(219, 215);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 35;
            pictureBox1.TabStop = false;
            // 
            // button10
            // 
            button10.BackColor = Color.Black;
            button10.ForeColor = Color.White;
            button10.Location = new Point(401, 340);
            button10.Name = "button10";
            button10.Size = new Size(321, 64);
            button10.TabIndex = 34;
            button10.Text = "Thoát";
            button10.UseVisualStyleBackColor = false;
            button10.Click += button10_Click;
            // 
            // button9
            // 
            button9.BackColor = Color.Black;
            button9.ForeColor = Color.White;
            button9.Location = new Point(356, 238);
            button9.Name = "button9";
            button9.Size = new Size(157, 23);
            button9.TabIndex = 33;
            button9.Text = "Thống kê theo sản phẩm";
            button9.UseVisualStyleBackColor = false;
            button9.Click += button9_Click;
            // 
            // btnQuanLyTaiKhoan
            // 
            btnQuanLyTaiKhoan.BackColor = Color.Black;
            btnQuanLyTaiKhoan.ForeColor = Color.White;
            btnQuanLyTaiKhoan.Location = new Point(356, 290);
            btnQuanLyTaiKhoan.Name = "btnQuanLyTaiKhoan";
            btnQuanLyTaiKhoan.Size = new Size(157, 23);
            btnQuanLyTaiKhoan.TabIndex = 32;
            btnQuanLyTaiKhoan.Text = "Quản lý tài khoản";
            btnQuanLyTaiKhoan.UseVisualStyleBackColor = false;
            btnQuanLyTaiKhoan.Click += btnQuanLyTaiKhoan_Click_1;
            // 
            // button7
            // 
            button7.BackColor = Color.Black;
            button7.ForeColor = Color.White;
            button7.Location = new Point(600, 238);
            button7.Name = "button7";
            button7.Size = new Size(157, 23);
            button7.TabIndex = 31;
            button7.Text = "Thống kê theo nhân viên";
            button7.UseVisualStyleBackColor = false;
            button7.Click += button7_Click;
            // 
            // button6
            // 
            button6.BackColor = Color.Black;
            button6.ForeColor = Color.White;
            button6.Location = new Point(600, 133);
            button6.Name = "button6";
            button6.Size = new Size(157, 23);
            button6.TabIndex = 30;
            button6.Text = "Quản Lý Thẻ Lưu Động";
            button6.UseVisualStyleBackColor = false;
            button6.Click += button6_Click;
            // 
            // button5
            // 
            button5.BackColor = Color.Black;
            button5.ForeColor = Color.White;
            button5.Location = new Point(356, 133);
            button5.Name = "button5";
            button5.Size = new Size(157, 23);
            button5.TabIndex = 29;
            button5.Text = "Quản lý phiếu bán hàng";
            button5.UseVisualStyleBackColor = false;
            button5.Click += button5_Click;
            // 
            // btnDoiMatKhau
            // 
            btnDoiMatKhau.BackColor = Color.Black;
            btnDoiMatKhau.ForeColor = Color.White;
            btnDoiMatKhau.Location = new Point(600, 290);
            btnDoiMatKhau.Name = "btnDoiMatKhau";
            btnDoiMatKhau.Size = new Size(157, 23);
            btnDoiMatKhau.TabIndex = 28;
            btnDoiMatKhau.Text = "Đổi mật khẩu";
            btnDoiMatKhau.UseVisualStyleBackColor = false;
            btnDoiMatKhau.Click += button4_Click;
            // 
            // button3
            // 
            button3.BackColor = Color.Black;
            button3.ForeColor = Color.White;
            button3.Location = new Point(600, 189);
            button3.Name = "button3";
            button3.Size = new Size(157, 23);
            button3.TabIndex = 27;
            button3.Text = "Quản lý sản phẩm";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.Black;
            button2.ForeColor = Color.White;
            button2.Location = new Point(356, 189);
            button2.Name = "button2";
            button2.Size = new Size(157, 23);
            button2.TabIndex = 26;
            button2.Text = "Quản lý loại sản phẩm";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Times New Roman", 30F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(379, 58);
            label1.Name = "label1";
            label1.Size = new Size(312, 45);
            label1.TabIndex = 24;
            label1.Text = "Chọn Chức Năng";
            // 
            // ManHinhChinh
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 192, 128);
            ClientSize = new Size(800, 450);
            Controls.Add(label2);
            Controls.Add(pictureBox1);
            Controls.Add(button10);
            Controls.Add(button9);
            Controls.Add(btnQuanLyTaiKhoan);
            Controls.Add(button7);
            Controls.Add(button6);
            Controls.Add(button5);
            Controls.Add(btnDoiMatKhau);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(label1);
            Name = "ManHinhChinh";
            Text = "ManHinhChinh";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label2;
        private PictureBox pictureBox1;
        private Button button10;
        private Button button9;
        private Button btnQuanLyTaiKhoan;
        private Button button7;
        private Button button6;
        private Button button5;
        private Button btnDoiMatKhau;
        private Button button3;
        private Button button2;
        private Label label1;
    }
}