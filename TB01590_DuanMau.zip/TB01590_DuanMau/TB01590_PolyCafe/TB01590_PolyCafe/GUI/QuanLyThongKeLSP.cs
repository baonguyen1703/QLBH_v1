﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BLL;
using DTO;

namespace GUI
{
    public partial class QuanLyThongKeLSP : Form
    {
        public QuanLyThongKeLSP()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnThongKe_Click(object sender, EventArgs e)
        {
            string loai = cbxLoaiSanPham.SelectedValue.ToString();
            DateTime bd = dtpTuNgay.Value.Date;
            DateTime kt = dtpDenNgay.Value.Date;

            BLL_ThongKe bLL_ThongKe = new BLL_ThongKe();
            List<TKDoanhThuLoaiSP> result = bLL_ThongKe.getThongKeLoaiSP(loai, bd, kt);
            dgrDanhSachThongKe.DataSource = result;
        }
        private void LoadLoaiSanPham()
        {
            try
            {
                BLL_LoaiSanPham bLL_LoaiSanPham = new BLL_LoaiSanPham();
                List<LoaiSanPham> dsLoai = bLL_LoaiSanPham.GetLoaiSanPhamList();

                dsLoai.Insert(0, new LoaiSanPham() { MaLoai = string.Empty, TenLoai = string.Format("--Tất Cả--") });
                cbxLoaiSanPham.DataSource = dsLoai;
                cbxLoaiSanPham.ValueMember = "MaLoai";
                cbxLoaiSanPham.DisplayMember = "TenLoai";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi tải danh sách loại sản phẩm" + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void QuanLyThongKeLSP_Load(object sender, EventArgs e)
        {
            DateTime firstDayOfMonth = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1);
            dtpTuNgay.Value = firstDayOfMonth;
            LoadLoaiSanPham();
            btnThongKe_Click(sender, e);
        }
    }
}
