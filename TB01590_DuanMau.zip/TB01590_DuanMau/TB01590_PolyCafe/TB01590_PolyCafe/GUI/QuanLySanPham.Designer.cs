﻿namespace GUI
{
    partial class QuanLySanPham
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox2 = new GroupBox();
            btnUploadSanPham = new Button();
            btnMoiSanPham = new Button();
            cboLoaiSanPham = new ComboBox();
            rdbDeActive = new RadioButton();
            rdbActive = new RadioButton();
            label7 = new Label();
            pbHinhAnh = new PictureBox();
            label6 = new Label();
            btnXoaSanPham = new Button();
            btnSuaSanPham = new Button();
            btnThemSanPham = new Button();
            txtDonGia = new TextBox();
            txtTenSanPham = new TextBox();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            txtMaSanPham = new TextBox();
            label1 = new Label();
            button1 = new Button();
            groupBox1 = new GroupBox();
            dvgDanhSachSP = new DataGridView();
            groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pbHinhAnh).BeginInit();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dvgDanhSachSP).BeginInit();
            SuspendLayout();
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(btnUploadSanPham);
            groupBox2.Controls.Add(btnMoiSanPham);
            groupBox2.Controls.Add(cboLoaiSanPham);
            groupBox2.Controls.Add(rdbDeActive);
            groupBox2.Controls.Add(rdbActive);
            groupBox2.Controls.Add(label7);
            groupBox2.Controls.Add(pbHinhAnh);
            groupBox2.Controls.Add(label6);
            groupBox2.Controls.Add(btnXoaSanPham);
            groupBox2.Controls.Add(btnSuaSanPham);
            groupBox2.Controls.Add(btnThemSanPham);
            groupBox2.Controls.Add(txtDonGia);
            groupBox2.Controls.Add(txtTenSanPham);
            groupBox2.Controls.Add(label4);
            groupBox2.Controls.Add(label3);
            groupBox2.Controls.Add(label2);
            groupBox2.Controls.Add(txtMaSanPham);
            groupBox2.Location = new Point(12, 79);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(347, 359);
            groupBox2.TabIndex = 12;
            groupBox2.TabStop = false;
            groupBox2.Text = "Thông tin";
            // 
            // btnUploadSanPham
            // 
            btnUploadSanPham.Location = new Point(6, 224);
            btnUploadSanPham.Name = "btnUploadSanPham";
            btnUploadSanPham.Size = new Size(75, 23);
            btnUploadSanPham.TabIndex = 19;
            btnUploadSanPham.Text = "Chọn Ảnh";
            btnUploadSanPham.UseVisualStyleBackColor = true;
            // 
            // btnMoiSanPham
            // 
            btnMoiSanPham.Image = Properties.Resources.up_to_date2;
            btnMoiSanPham.ImageAlign = ContentAlignment.MiddleLeft;
            btnMoiSanPham.Location = new Point(262, 314);
            btnMoiSanPham.Name = "btnMoiSanPham";
            btnMoiSanPham.Size = new Size(75, 39);
            btnMoiSanPham.TabIndex = 18;
            btnMoiSanPham.Text = "Mới";
            btnMoiSanPham.TextAlign = ContentAlignment.MiddleRight;
            btnMoiSanPham.UseVisualStyleBackColor = true;
            btnMoiSanPham.Click += btnMoiSanPham_Click;
            // 
            // cboLoaiSanPham
            // 
            cboLoaiSanPham.FormattingEnabled = true;
            cboLoaiSanPham.Location = new Point(98, 169);
            cboLoaiSanPham.Name = "cboLoaiSanPham";
            cboLoaiSanPham.Size = new Size(158, 23);
            cboLoaiSanPham.TabIndex = 16;
            // 
            // rdbDeActive
            // 
            rdbDeActive.AutoSize = true;
            rdbDeActive.Location = new Point(98, 289);
            rdbDeActive.Name = "rdbDeActive";
            rdbDeActive.Size = new Size(114, 19);
            rdbDeActive.TabIndex = 15;
            rdbDeActive.TabStop = true;
            rdbDeActive.Text = "Chưa thanh toán";
            rdbDeActive.UseVisualStyleBackColor = true;
            // 
            // rdbActive
            // 
            rdbActive.AutoSize = true;
            rdbActive.Location = new Point(98, 264);
            rdbActive.Name = "rdbActive";
            rdbActive.Size = new Size(100, 19);
            rdbActive.TabIndex = 14;
            rdbActive.TabStop = true;
            rdbActive.Text = "Đã thanh toán";
            rdbActive.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(16, 275);
            label7.Name = "label7";
            label7.Size = new Size(59, 15);
            label7.TabIndex = 13;
            label7.Text = "Trạng thái";
            // 
            // pbHinhAnh
            // 
            pbHinhAnh.Location = new Point(98, 198);
            pbHinhAnh.Name = "pbHinhAnh";
            pbHinhAnh.Size = new Size(75, 61);
            pbHinhAnh.TabIndex = 12;
            pbHinhAnh.TabStop = false;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(16, 177);
            label6.Name = "label6";
            label6.Size = new Size(46, 15);
            label6.TabIndex = 10;
            label6.Text = "Mã loại";
            // 
            // btnXoaSanPham
            // 
            btnXoaSanPham.Image = Properties.Resources.delete;
            btnXoaSanPham.ImageAlign = ContentAlignment.MiddleLeft;
            btnXoaSanPham.Location = new Point(193, 314);
            btnXoaSanPham.Name = "btnXoaSanPham";
            btnXoaSanPham.Size = new Size(63, 39);
            btnXoaSanPham.TabIndex = 8;
            btnXoaSanPham.Text = "Xóa";
            btnXoaSanPham.TextAlign = ContentAlignment.MiddleRight;
            btnXoaSanPham.UseVisualStyleBackColor = true;
            btnXoaSanPham.Click += btnXoaSanPham_Click;
            // 
            // btnSuaSanPham
            // 
            btnSuaSanPham.Image = Properties.Resources.pen;
            btnSuaSanPham.ImageAlign = ContentAlignment.MiddleLeft;
            btnSuaSanPham.Location = new Point(98, 314);
            btnSuaSanPham.Name = "btnSuaSanPham";
            btnSuaSanPham.Size = new Size(89, 39);
            btnSuaSanPham.TabIndex = 7;
            btnSuaSanPham.Text = "Cập nhật";
            btnSuaSanPham.TextAlign = ContentAlignment.MiddleRight;
            btnSuaSanPham.UseVisualStyleBackColor = true;
            btnSuaSanPham.Click += btnSuaSanPham_Click;
            // 
            // btnThemSanPham
            // 
            btnThemSanPham.Image = Properties.Resources.plus;
            btnThemSanPham.ImageAlign = ContentAlignment.MiddleLeft;
            btnThemSanPham.Location = new Point(16, 314);
            btnThemSanPham.Name = "btnThemSanPham";
            btnThemSanPham.Size = new Size(76, 39);
            btnThemSanPham.TabIndex = 6;
            btnThemSanPham.Text = "Thêm";
            btnThemSanPham.TextAlign = ContentAlignment.MiddleRight;
            btnThemSanPham.UseVisualStyleBackColor = true;
            btnThemSanPham.Click += btnThemSanPham_Click;
            // 
            // txtDonGia
            // 
            txtDonGia.Location = new Point(98, 123);
            txtDonGia.Name = "txtDonGia";
            txtDonGia.Size = new Size(158, 23);
            txtDonGia.TabIndex = 5;
            // 
            // txtTenSanPham
            // 
            txtTenSanPham.Location = new Point(98, 75);
            txtTenSanPham.Name = "txtTenSanPham";
            txtTenSanPham.Size = new Size(158, 23);
            txtTenSanPham.TabIndex = 4;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(16, 131);
            label4.Name = "label4";
            label4.Size = new Size(48, 15);
            label4.TabIndex = 3;
            label4.Text = "Đơn giá";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(16, 83);
            label3.Name = "label3";
            label3.Size = new Size(80, 15);
            label3.TabIndex = 2;
            label3.Text = "Tên sản phẩm";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(16, 37);
            label2.Name = "label2";
            label2.Size = new Size(79, 15);
            label2.TabIndex = 1;
            label2.Text = "Mã sản phẩm";
            // 
            // txtMaSanPham
            // 
            txtMaSanPham.Location = new Point(98, 34);
            txtMaSanPham.Name = "txtMaSanPham";
            txtMaSanPham.Size = new Size(158, 23);
            txtMaSanPham.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 25F);
            label1.Location = new Point(255, 12);
            label1.Name = "label1";
            label1.Size = new Size(296, 46);
            label1.TabIndex = 14;
            label1.Text = "Quản Lý Sản Phẩm";
            // 
            // button1
            // 
            button1.BackColor = Color.Red;
            button1.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            button1.ForeColor = SystemColors.ControlLightLight;
            button1.Location = new Point(12, 12);
            button1.Name = "button1";
            button1.Size = new Size(156, 35);
            button1.TabIndex = 13;
            button1.Text = "Trờ về Menu";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(dvgDanhSachSP);
            groupBox1.Location = new Point(365, 79);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(608, 359);
            groupBox1.TabIndex = 11;
            groupBox1.TabStop = false;
            groupBox1.Text = "Sản phẩm";
            // 
            // dvgDanhSachSP
            // 
            dvgDanhSachSP.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dvgDanhSachSP.Location = new Point(9, 22);
            dvgDanhSachSP.Name = "dvgDanhSachSP";
            dvgDanhSachSP.Size = new Size(593, 321);
            dvgDanhSachSP.TabIndex = 0;
            dvgDanhSachSP.CellDoubleClick += dataGridView1_CellDoubleClick;
            // 
            // QuanLySanPham
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 192, 128);
            ClientSize = new Size(985, 450);
            Controls.Add(groupBox2);
            Controls.Add(label1);
            Controls.Add(button1);
            Controls.Add(groupBox1);
            Name = "QuanLySanPham";
            Text = "QuanLySanPham";
            Load += QuanLySanPham_Load_1;
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pbHinhAnh).EndInit();
            groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dvgDanhSachSP).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox groupBox2;
        private RadioButton rdbDeActive;
        private RadioButton rdbActive;
        private Label label7;
        private PictureBox pbHinhAnh;
        private Label label6;
        private Button btnXoaSanPham;
        private Button btnSuaSanPham;
        private Button btnThemSanPham;
        private TextBox txtDonGia;
        private TextBox txtTenSanPham;
        private Label label4;
        private Label label3;
        private Label label2;
        private TextBox txtMaSanPham;
        private Label label1;
        private Button button1;
        private GroupBox groupBox1;
        private DataGridView dvgDanhSachSP;
        private ComboBox cboLoaiSanPham;
        private Button btnMoiSanPham;
        private Button btnUploadSanPham;
    }
}