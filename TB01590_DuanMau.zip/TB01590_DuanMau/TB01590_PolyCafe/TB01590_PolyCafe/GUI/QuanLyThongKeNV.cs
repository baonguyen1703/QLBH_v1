﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BLL;
using DTO;

namespace GUI
{
    public partial class QuanLyThongKeNV : Form
    {
        public QuanLyThongKeNV()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnThongKe_Click(object sender, EventArgs e)
        {
            string maNV = cbxNhanVien.SelectedValue.ToString();
            DateTime bd = dtpTuNgay.Value.Date;
            DateTime kt = dtpDenNgay.Value.Date;

            BLL_ThongKe bLL_ThongKe = new BLL_ThongKe();
            List<TKDoanhThuTheoNhanVien> result = bLL_ThongKe.getThongKeNhanVien(maNV, bd, kt);
            dgrDanhSachThongKe.DataSource = result;
        }

        private void QuanLyThongKeNV_Load(object sender, EventArgs e)
        {
            DateTime firstDayOfMonth = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1);

            dtpTuNgay.Value = firstDayOfMonth;
            LoadNhanVien();

            btnThongKe_Click(sender, e);
        }
        private void LoadNhanVien()
        {
            try
            {
                BLL_NhanVien bLL_NhanVien = new BLL_NhanVien();
                List<NhanVien> dsNhanVien = bLL_NhanVien.GetNhanVienList();
                dsNhanVien.Insert(0, new NhanVien() { MaNhanVien = string.Empty, HoTen = string.Format("--Tất Cả--") });
                cbxNhanVien.DataSource = dsNhanVien;
                cbxNhanVien.ValueMember = "MaNhanVien";
                cbxNhanVien.DisplayMember = "HoTen";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi tải danh sách nhân viên" + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
