﻿namespace GUI
{
    partial class AChiTietPhieu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            button1 = new Button();
            sqlCommand1 = new Microsoft.Data.SqlClient.SqlCommand();
            btnXoaChiTiet = new Button();
            btnThemChiTiet = new Button();
            lbNgayLap = new Label();
            label7 = new Label();
            lbMaPhieu = new Label();
            label8 = new Label();
            lbChuSoHuu = new Label();
            label9 = new Label();
            dgrSanPham = new DataGridView();
            groupBox1 = new GroupBox();
            label2 = new Label();
            txtPhanTram = new TextBox();
            txtThanhTien = new TextBox();
            txtGiamGia = new TextBox();
            txtDichVu = new TextBox();
            txtTong = new TextBox();
            label3 = new Label();
            label4 = new Label();
            label6 = new Label();
            label5 = new Label();
            dgrChiTiet = new DataGridView();
            sqlCommandBuilder1 = new Microsoft.Data.SqlClient.SqlCommandBuilder();
            button2 = new Button();
            ((System.ComponentModel.ISupportInitialize)dgrSanPham).BeginInit();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgrChiTiet).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 25F);
            label1.Location = new Point(205, 10);
            label1.Name = "label1";
            label1.Size = new Size(378, 46);
            label1.TabIndex = 22;
            label1.Text = "Chi Tiết Phiếu Bán Hàng";
            // 
            // button1
            // 
            button1.BackColor = Color.Red;
            button1.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            button1.ForeColor = Color.White;
            button1.Location = new Point(12, 14);
            button1.Name = "button1";
            button1.Size = new Size(156, 35);
            button1.TabIndex = 21;
            button1.Text = "Trờ về Menu";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // sqlCommand1
            // 
            sqlCommand1.CommandTimeout = 30;
            sqlCommand1.EnableOptimizedParameterBinding = false;
            // 
            // btnXoaChiTiet
            // 
            btnXoaChiTiet.Location = new Point(465, 265);
            btnXoaChiTiet.Margin = new Padding(3, 2, 3, 2);
            btnXoaChiTiet.Name = "btnXoaChiTiet";
            btnXoaChiTiet.Size = new Size(53, 22);
            btnXoaChiTiet.TabIndex = 23;
            btnXoaChiTiet.Text = ">>";
            btnXoaChiTiet.UseVisualStyleBackColor = true;
            btnXoaChiTiet.Click += btnXoaChiTiet_Click_1;
            // 
            // btnThemChiTiet
            // 
            btnThemChiTiet.Location = new Point(465, 194);
            btnThemChiTiet.Margin = new Padding(3, 2, 3, 2);
            btnThemChiTiet.Name = "btnThemChiTiet";
            btnThemChiTiet.Size = new Size(53, 22);
            btnThemChiTiet.TabIndex = 24;
            btnThemChiTiet.Text = "<<";
            btnThemChiTiet.UseVisualStyleBackColor = true;
            btnThemChiTiet.Click += btnThemChiTiet_Click_1;
            // 
            // lbNgayLap
            // 
            lbNgayLap.AutoSize = true;
            lbNgayLap.Font = new Font("Segoe UI", 11F);
            lbNgayLap.ForeColor = Color.Maroon;
            lbNgayLap.Location = new Point(817, 58);
            lbNgayLap.Name = "lbNgayLap";
            lbNgayLap.Size = new Size(70, 20);
            lbNgayLap.TabIndex = 25;
            lbNgayLap.Text = "Mã Phiếu";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 11F);
            label7.ForeColor = Color.Maroon;
            label7.Location = new Point(727, 58);
            label7.Name = "label7";
            label7.Size = new Size(75, 20);
            label7.TabIndex = 26;
            label7.Text = "Ngày Lập:";
            // 
            // lbMaPhieu
            // 
            lbMaPhieu.AutoSize = true;
            lbMaPhieu.Font = new Font("Segoe UI", 11F);
            lbMaPhieu.ForeColor = Color.Maroon;
            lbMaPhieu.Location = new Point(495, 58);
            lbMaPhieu.Name = "lbMaPhieu";
            lbMaPhieu.Size = new Size(70, 20);
            lbMaPhieu.TabIndex = 27;
            lbMaPhieu.Text = "Mã Phiếu";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 11F);
            label8.ForeColor = Color.Maroon;
            label8.Location = new Point(405, 58);
            label8.Name = "label8";
            label8.Size = new Size(73, 20);
            label8.TabIndex = 28;
            label8.Text = "Mã Phiếu:";
            // 
            // lbChuSoHuu
            // 
            lbChuSoHuu.AutoSize = true;
            lbChuSoHuu.Font = new Font("Segoe UI", 11F);
            lbChuSoHuu.ForeColor = Color.Maroon;
            lbChuSoHuu.Location = new Point(141, 58);
            lbChuSoHuu.Name = "lbChuSoHuu";
            lbChuSoHuu.Size = new Size(70, 20);
            lbChuSoHuu.TabIndex = 29;
            lbChuSoHuu.Text = "Mã Phiếu";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI", 11F);
            label9.ForeColor = Color.Maroon;
            label9.Location = new Point(34, 58);
            label9.Name = "label9";
            label9.Size = new Size(90, 20);
            label9.TabIndex = 30;
            label9.Text = "Chủ Sở Hữu:";
            // 
            // dgrSanPham
            // 
            dgrSanPham.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgrSanPham.Location = new Point(524, 99);
            dgrSanPham.Margin = new Padding(3, 2, 3, 2);
            dgrSanPham.Name = "dgrSanPham";
            dgrSanPham.ReadOnly = true;
            dgrSanPham.RowHeadersWidth = 51;
            dgrSanPham.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgrSanPham.Size = new Size(426, 404);
            dgrSanPham.TabIndex = 32;
            dgrSanPham.CellContentClick += dgrSanPham_CellContentClick;
            dgrSanPham.CellDoubleClick += dgrSanPham_CellDoubleClick;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(txtPhanTram);
            groupBox1.Controls.Add(txtThanhTien);
            groupBox1.Controls.Add(txtGiamGia);
            groupBox1.Controls.Add(txtDichVu);
            groupBox1.Controls.Add(txtTong);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(label6);
            groupBox1.Controls.Add(label5);
            groupBox1.Location = new Point(2, 386);
            groupBox1.Margin = new Padding(3, 2, 3, 2);
            groupBox1.Name = "groupBox1";
            groupBox1.Padding = new Padding(3, 2, 3, 2);
            groupBox1.Size = new Size(457, 131);
            groupBox1.TabIndex = 34;
            groupBox1.TabStop = false;
            groupBox1.Text = "Thông Tin Thanh Toán";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(138, 62);
            label2.Name = "label2";
            label2.Size = new Size(17, 15);
            label2.TabIndex = 3;
            label2.Text = "%";
            // 
            // txtPhanTram
            // 
            txtPhanTram.Location = new Point(86, 60);
            txtPhanTram.Margin = new Padding(3, 2, 3, 2);
            txtPhanTram.Name = "txtPhanTram";
            txtPhanTram.Size = new Size(46, 23);
            txtPhanTram.TabIndex = 2;
            // 
            // txtThanhTien
            // 
            txtThanhTien.Location = new Point(86, 95);
            txtThanhTien.Margin = new Padding(3, 2, 3, 2);
            txtThanhTien.Name = "txtThanhTien";
            txtThanhTien.ReadOnly = true;
            txtThanhTien.Size = new Size(354, 23);
            txtThanhTien.TabIndex = 1;
            // 
            // txtGiamGia
            // 
            txtGiamGia.Location = new Point(180, 60);
            txtGiamGia.Margin = new Padding(3, 2, 3, 2);
            txtGiamGia.Name = "txtGiamGia";
            txtGiamGia.ReadOnly = true;
            txtGiamGia.Size = new Size(260, 23);
            txtGiamGia.TabIndex = 1;
            // 
            // txtDichVu
            // 
            txtDichVu.Location = new Point(313, 24);
            txtDichVu.Margin = new Padding(3, 2, 3, 2);
            txtDichVu.Name = "txtDichVu";
            txtDichVu.ReadOnly = true;
            txtDichVu.Size = new Size(127, 23);
            txtDichVu.TabIndex = 1;
            // 
            // txtTong
            // 
            txtTong.Location = new Point(86, 22);
            txtTong.Margin = new Padding(3, 2, 3, 2);
            txtTong.Name = "txtTong";
            txtTong.ReadOnly = true;
            txtTong.Size = new Size(161, 23);
            txtTong.TabIndex = 1;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(13, 99);
            label3.Name = "label3";
            label3.Size = new Size(68, 15);
            label3.TabIndex = 0;
            label3.Text = "Thành Tiền:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(13, 62);
            label4.Name = "label4";
            label4.Size = new Size(55, 15);
            label4.TabIndex = 0;
            label4.Text = "Giảm Giá";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(253, 26);
            label6.Name = "label6";
            label6.Size = new Size(51, 15);
            label6.TabIndex = 0;
            label6.Text = "Dịch Vụ:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(13, 23);
            label5.Name = "label5";
            label5.Size = new Size(40, 15);
            label5.TabIndex = 0;
            label5.Text = "Tổng :";
            // 
            // dgrChiTiet
            // 
            dgrChiTiet.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgrChiTiet.Location = new Point(2, 99);
            dgrChiTiet.Margin = new Padding(3, 2, 3, 2);
            dgrChiTiet.Name = "dgrChiTiet";
            dgrChiTiet.RowHeadersWidth = 51;
            dgrChiTiet.Size = new Size(457, 280);
            dgrChiTiet.TabIndex = 33;
            dgrChiTiet.CellContentClick += dgrChiTiet_CellContentClick;
            dgrChiTiet.CellEndEdit += dgrChiTiet_CellEndEdit;
            // 
            // button2
            // 
            button2.Location = new Point(666, 16);
            button2.Name = "button2";
            button2.RightToLeft = RightToLeft.No;
            button2.Size = new Size(75, 23);
            button2.TabIndex = 35;
            button2.Text = "Mới";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // AChiTietPhieu
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 192, 128);
            ClientSize = new Size(952, 514);
            Controls.Add(button2);
            Controls.Add(groupBox1);
            Controls.Add(dgrChiTiet);
            Controls.Add(dgrSanPham);
            Controls.Add(lbNgayLap);
            Controls.Add(label7);
            Controls.Add(lbMaPhieu);
            Controls.Add(label8);
            Controls.Add(lbChuSoHuu);
            Controls.Add(label9);
            Controls.Add(btnXoaChiTiet);
            Controls.Add(btnThemChiTiet);
            Controls.Add(label1);
            Controls.Add(button1);
            Name = "AChiTietPhieu";
            Text = "BanHang";
            Load += AChiTietPhieu_Load_1;
            ((System.ComponentModel.ISupportInitialize)dgrSanPham).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgrChiTiet).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label label1;
        private Button button1;
        private Microsoft.Data.SqlClient.SqlCommand sqlCommand1;
        private Button btnXoaChiTiet;
        private Button btnThemChiTiet;
        private Label lbNgayLap;
        private Label label7;
        private Label lbMaPhieu;
        private Label label8;
        private Label lbChuSoHuu;
        private Label label9;
        private DataGridView dgrSanPham;
        private GroupBox groupBox1;
        private Label label2;
        private TextBox txtPhanTram;
        private TextBox txtThanhTien;
        private TextBox txtGiamGia;
        private TextBox txtDichVu;
        private TextBox txtTong;
        private Label label3;
        private Label label4;
        private Label label6;
        private Label label5;
        private DataGridView dgrChiTiet;
        private Microsoft.Data.SqlClient.SqlCommandBuilder sqlCommandBuilder1;
        private Button button2;
    }
}