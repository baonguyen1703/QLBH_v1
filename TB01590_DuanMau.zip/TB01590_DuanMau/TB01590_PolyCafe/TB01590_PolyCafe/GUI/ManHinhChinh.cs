﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GUI
{
    public partial class ManHinhChinh : Form
    {
        public ManHinhChinh()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnQuanLyTaiKhoan_Click_1(object sender, EventArgs e)
        {
            QuanLyTaiKhoan quanLyTaiKhoan = new QuanLyTaiKhoan();
            quanLyTaiKhoan.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            DoiMatKhau doiMatKhau = new DoiMatKhau();
            doiMatKhau.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            QuanLySanPham quanlySanPham = new QuanLySanPham();
            quanlySanPham.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            QuanLyLoaiSanPham quanLyLoaiSanPham = new QuanLyLoaiSanPham();
            quanLyLoaiSanPham.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            QuanLyPhieuBanHang quanLyPhieuBanHang = new QuanLyPhieuBanHang();
            quanLyPhieuBanHang.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            QuanLyTheLuuDong quanLyTheLuuDong = new QuanLyTheLuuDong();
            quanLyTheLuuDong.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            QuanLyThongKeNV quanLyThongKeNV = new QuanLyThongKeNV();
            quanLyThongKeNV.Show();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            QuanLyThongKeLSP quanLyThongKeLSP = new QuanLyThongKeLSP();
            quanLyThongKeLSP.Show();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Xác nhận thoát chương trình?",
                                           "Thoát",
                                           MessageBoxButtons.YesNo,
                                           MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
    }
}
