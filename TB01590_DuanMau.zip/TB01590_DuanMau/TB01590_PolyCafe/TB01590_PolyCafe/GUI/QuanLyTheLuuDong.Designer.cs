﻿namespace GUI
{
    partial class QuanLyTheLuuDong
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox2 = new GroupBox();
            chkHoatDong = new CheckBox();
            btnMoi = new Button();
            pictureBox1 = new PictureBox();
            btnXoa = new Button();
            btnSua = new Button();
            btnThem = new Button();
            label5 = new Label();
            txtChuSoHuu = new TextBox();
            label4 = new Label();
            label2 = new Label();
            txtMaThe = new TextBox();
            label1 = new Label();
            button1 = new Button();
            groupBox1 = new GroupBox();
            dgvDanhSachThe = new DataGridView();
            button5 = new Button();
            textBox3 = new TextBox();
            groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvDanhSachThe).BeginInit();
            SuspendLayout();
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(chkHoatDong);
            groupBox2.Controls.Add(btnMoi);
            groupBox2.Controls.Add(pictureBox1);
            groupBox2.Controls.Add(btnXoa);
            groupBox2.Controls.Add(btnSua);
            groupBox2.Controls.Add(btnThem);
            groupBox2.Controls.Add(label5);
            groupBox2.Controls.Add(txtChuSoHuu);
            groupBox2.Controls.Add(label4);
            groupBox2.Controls.Add(label2);
            groupBox2.Controls.Add(txtMaThe);
            groupBox2.Location = new Point(12, 81);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(274, 359);
            groupBox2.TabIndex = 20;
            groupBox2.TabStop = false;
            groupBox2.Text = "Thông tin thẻ";
            // 
            // chkHoatDong
            // 
            chkHoatDong.AutoSize = true;
            chkHoatDong.Location = new Point(94, 196);
            chkHoatDong.Name = "chkHoatDong";
            chkHoatDong.Size = new Size(84, 19);
            chkHoatDong.TabIndex = 20;
            chkHoatDong.Text = "Hoạt Động";
            chkHoatDong.UseVisualStyleBackColor = true;
            // 
            // btnMoi
            // 
            btnMoi.Image = Properties.Resources.up_to_date;
            btnMoi.ImageAlign = ContentAlignment.MiddleLeft;
            btnMoi.Location = new Point(104, 296);
            btnMoi.Name = "btnMoi";
            btnMoi.Size = new Size(75, 39);
            btnMoi.TabIndex = 19;
            btnMoi.Text = "Mới";
            btnMoi.TextAlign = ContentAlignment.MiddleRight;
            btnMoi.UseVisualStyleBackColor = true;
            btnMoi.Click += txtMoi_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.coffee;
            pictureBox1.Location = new Point(42, 25);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(178, 93);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 18;
            pictureBox1.TabStop = false;
            // 
            // btnXoa
            // 
            btnXoa.Image = Properties.Resources.delete;
            btnXoa.ImageAlign = ContentAlignment.MiddleLeft;
            btnXoa.Location = new Point(16, 296);
            btnXoa.Name = "btnXoa";
            btnXoa.Size = new Size(75, 39);
            btnXoa.TabIndex = 17;
            btnXoa.Text = "Xóa";
            btnXoa.TextAlign = ContentAlignment.MiddleRight;
            btnXoa.UseVisualStyleBackColor = true;
            btnXoa.Click += btnXoa_Click;
            // 
            // btnSua
            // 
            btnSua.Image = Properties.Resources.pen;
            btnSua.ImageAlign = ContentAlignment.MiddleLeft;
            btnSua.Location = new Point(104, 239);
            btnSua.Name = "btnSua";
            btnSua.Size = new Size(74, 39);
            btnSua.TabIndex = 16;
            btnSua.Text = "Sửa";
            btnSua.TextAlign = ContentAlignment.MiddleRight;
            btnSua.UseVisualStyleBackColor = true;
            btnSua.Click += btnSua_Click;
            // 
            // btnThem
            // 
            btnThem.Image = Properties.Resources.plus;
            btnThem.ImageAlign = ContentAlignment.MiddleLeft;
            btnThem.Location = new Point(15, 239);
            btnThem.Name = "btnThem";
            btnThem.Size = new Size(76, 39);
            btnThem.TabIndex = 15;
            btnThem.Text = "Thêm";
            btnThem.TextAlign = ContentAlignment.MiddleRight;
            btnThem.UseVisualStyleBackColor = true;
            btnThem.Click += btnThem_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(15, 196);
            label5.Name = "label5";
            label5.Size = new Size(59, 15);
            label5.TabIndex = 9;
            label5.Text = "Trạng thái";
            label5.Click += label5_Click;
            // 
            // txtChuSoHuu
            // 
            txtChuSoHuu.Location = new Point(134, 160);
            txtChuSoHuu.Name = "txtChuSoHuu";
            txtChuSoHuu.Size = new Size(122, 23);
            txtChuSoHuu.TabIndex = 4;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(15, 168);
            label4.Name = "label4";
            label4.Size = new Size(68, 15);
            label4.TabIndex = 3;
            label4.Text = "Chủ sở hữu";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(15, 132);
            label2.Name = "label2";
            label2.Size = new Size(44, 15);
            label2.TabIndex = 1;
            label2.Text = "Mã thẻ";
            // 
            // txtMaThe
            // 
            txtMaThe.Location = new Point(134, 124);
            txtMaThe.Name = "txtMaThe";
            txtMaThe.Size = new Size(122, 23);
            txtMaThe.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 25F);
            label1.Location = new Point(237, 10);
            label1.Name = "label1";
            label1.Size = new Size(360, 46);
            label1.TabIndex = 22;
            label1.Text = "Quản Lý Thẻ Lưu Động";
            // 
            // button1
            // 
            button1.BackColor = Color.Red;
            button1.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            button1.ForeColor = Color.White;
            button1.Location = new Point(12, 14);
            button1.Name = "button1";
            button1.Size = new Size(156, 35);
            button1.TabIndex = 21;
            button1.Text = "Trờ về Menu ";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(dgvDanhSachThe);
            groupBox1.Controls.Add(button5);
            groupBox1.Controls.Add(textBox3);
            groupBox1.Location = new Point(292, 81);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(487, 359);
            groupBox1.TabIndex = 19;
            groupBox1.TabStop = false;
            groupBox1.Text = "Danh sách thẻ";
            // 
            // dgvDanhSachThe
            // 
            dgvDanhSachThe.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvDanhSachThe.Location = new Point(9, 46);
            dgvDanhSachThe.Name = "dgvDanhSachThe";
            dgvDanhSachThe.Size = new Size(460, 317);
            dgvDanhSachThe.TabIndex = 0;
            dgvDanhSachThe.CellDoubleClick += dataGridView1_CellDoubleClick;
            // 
            // button5
            // 
            button5.Location = new Point(394, 17);
            button5.Name = "button5";
            button5.Size = new Size(75, 23);
            button5.TabIndex = 14;
            button5.Text = "Tìm";
            button5.UseVisualStyleBackColor = true;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(266, 17);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(122, 23);
            textBox3.TabIndex = 13;
            // 
            // QuanLyTheLuuDong
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 192, 128);
            ClientSize = new Size(796, 450);
            Controls.Add(groupBox2);
            Controls.Add(label1);
            Controls.Add(button1);
            Controls.Add(groupBox1);
            Name = "QuanLyTheLuuDong";
            Text = "QuanLyTheLuuDong";
            Load += QuanLyTheLuuDong_Load_1;
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvDanhSachThe).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox groupBox2;
        private PictureBox pictureBox1;
        private Button btnXoa;
        private Button btnSua;
        private Button btnThem;
        private Label label5;
        private TextBox txtChuSoHuu;
        private Label label4;
        private Label label2;
        private TextBox txtMaThe;
        private Label label1;
        private Button button1;
        private GroupBox groupBox1;
        private DataGridView dgvDanhSachThe;
        private Button button5;
        private TextBox textBox3;
        private Button btnMoi;
        private CheckBox chkHoatDong;
    }
}