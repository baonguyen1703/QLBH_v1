﻿namespace GUI
{
    partial class QuanLyPhieuBanHang
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox2 = new GroupBox();
            btnMoiPhieu = new Button();
            dtpNgayTao = new DateTimePicker();
            cboNhanVienBH = new ComboBox();
            cboMaTheLuuDong = new ComboBox();
            btnXoaPhieu = new Button();
            btnSuaPhieu = new Button();
            btnThemPhieu = new Button();
            rdbPaid = new RadioButton();
            rdbConfirmation = new RadioButton();
            label6 = new Label();
            label5 = new Label();
            txtMaPhieu = new TextBox();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            button1 = new Button();
            groupBox1 = new GroupBox();
            dvgDanhSachPhieu = new DataGridView();
            groupBox2.SuspendLayout();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dvgDanhSachPhieu).BeginInit();
            SuspendLayout();
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(btnMoiPhieu);
            groupBox2.Controls.Add(dtpNgayTao);
            groupBox2.Controls.Add(cboNhanVienBH);
            groupBox2.Controls.Add(cboMaTheLuuDong);
            groupBox2.Controls.Add(btnXoaPhieu);
            groupBox2.Controls.Add(btnSuaPhieu);
            groupBox2.Controls.Add(btnThemPhieu);
            groupBox2.Controls.Add(rdbPaid);
            groupBox2.Controls.Add(rdbConfirmation);
            groupBox2.Controls.Add(label6);
            groupBox2.Controls.Add(label5);
            groupBox2.Controls.Add(txtMaPhieu);
            groupBox2.Controls.Add(label4);
            groupBox2.Controls.Add(label3);
            groupBox2.Controls.Add(label2);
            groupBox2.Location = new Point(12, 94);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(371, 333);
            groupBox2.TabIndex = 16;
            groupBox2.TabStop = false;
            groupBox2.Text = "Thông tin phiếu";
            // 
            // btnMoiPhieu
            // 
            btnMoiPhieu.Image = Properties.Resources.up_to_date1;
            btnMoiPhieu.ImageAlign = ContentAlignment.MiddleLeft;
            btnMoiPhieu.Location = new Point(288, 267);
            btnMoiPhieu.Name = "btnMoiPhieu";
            btnMoiPhieu.Size = new Size(75, 42);
            btnMoiPhieu.TabIndex = 19;
            btnMoiPhieu.Text = "Mới";
            btnMoiPhieu.TextAlign = ContentAlignment.MiddleRight;
            btnMoiPhieu.UseVisualStyleBackColor = true;
            btnMoiPhieu.Click += btnMoiPhieu_Click;
            // 
            // dtpNgayTao
            // 
            dtpNgayTao.Location = new Point(134, 177);
            dtpNgayTao.Name = "dtpNgayTao";
            dtpNgayTao.Size = new Size(200, 23);
            dtpNgayTao.TabIndex = 18;
            // 
            // cboNhanVienBH
            // 
            cboNhanVienBH.FormattingEnabled = true;
            cboNhanVienBH.Location = new Point(134, 128);
            cboNhanVienBH.Name = "cboNhanVienBH";
            cboNhanVienBH.Size = new Size(121, 23);
            cboNhanVienBH.TabIndex = 17;
            // 
            // cboMaTheLuuDong
            // 
            cboMaTheLuuDong.FormattingEnabled = true;
            cboMaTheLuuDong.Location = new Point(134, 37);
            cboMaTheLuuDong.Name = "cboMaTheLuuDong";
            cboMaTheLuuDong.Size = new Size(121, 23);
            cboMaTheLuuDong.TabIndex = 16;
            // 
            // btnXoaPhieu
            // 
            btnXoaPhieu.Image = Properties.Resources.delete;
            btnXoaPhieu.ImageAlign = ContentAlignment.MiddleLeft;
            btnXoaPhieu.Location = new Point(202, 267);
            btnXoaPhieu.Name = "btnXoaPhieu";
            btnXoaPhieu.Size = new Size(73, 42);
            btnXoaPhieu.TabIndex = 15;
            btnXoaPhieu.Text = "Xóa";
            btnXoaPhieu.TextAlign = ContentAlignment.MiddleRight;
            btnXoaPhieu.UseVisualStyleBackColor = true;
            btnXoaPhieu.Click += btnXoaPhieu_Click;
            // 
            // btnSuaPhieu
            // 
            btnSuaPhieu.Image = Properties.Resources.pen;
            btnSuaPhieu.ImageAlign = ContentAlignment.MiddleLeft;
            btnSuaPhieu.Location = new Point(98, 267);
            btnSuaPhieu.Name = "btnSuaPhieu";
            btnSuaPhieu.Size = new Size(98, 42);
            btnSuaPhieu.TabIndex = 14;
            btnSuaPhieu.Text = "Cập nhật";
            btnSuaPhieu.TextAlign = ContentAlignment.MiddleRight;
            btnSuaPhieu.UseVisualStyleBackColor = true;
            btnSuaPhieu.Click += btnSuaPhieu_Click;
            // 
            // btnThemPhieu
            // 
            btnThemPhieu.Image = Properties.Resources.plus;
            btnThemPhieu.ImageAlign = ContentAlignment.MiddleLeft;
            btnThemPhieu.Location = new Point(18, 267);
            btnThemPhieu.Name = "btnThemPhieu";
            btnThemPhieu.Size = new Size(74, 42);
            btnThemPhieu.TabIndex = 13;
            btnThemPhieu.Text = "Thêm";
            btnThemPhieu.TextAlign = ContentAlignment.MiddleRight;
            btnThemPhieu.UseVisualStyleBackColor = true;
            btnThemPhieu.Click += btnThemPhieu_Click;
            // 
            // rdbPaid
            // 
            rdbPaid.AutoSize = true;
            rdbPaid.Location = new Point(98, 242);
            rdbPaid.Name = "rdbPaid";
            rdbPaid.Size = new Size(103, 19);
            rdbPaid.TabIndex = 12;
            rdbPaid.TabStop = true;
            rdbPaid.Text = "Đã Thanh Toán";
            rdbPaid.UseVisualStyleBackColor = true;
            // 
            // rdbConfirmation
            // 
            rdbConfirmation.AutoSize = true;
            rdbConfirmation.Location = new Point(98, 217);
            rdbConfirmation.Name = "rdbConfirmation";
            rdbConfirmation.Size = new Size(111, 19);
            rdbConfirmation.TabIndex = 1;
            rdbConfirmation.TabStop = true;
            rdbConfirmation.Text = "Chờ Thanh Toán";
            rdbConfirmation.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(16, 177);
            label6.Name = "label6";
            label6.Size = new Size(55, 15);
            label6.TabIndex = 10;
            label6.Text = "Ngày tạo";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(16, 217);
            label5.Name = "label5";
            label5.Size = new Size(59, 15);
            label5.TabIndex = 9;
            label5.Text = "Trạng thái";
            // 
            // txtMaPhieu
            // 
            txtMaPhieu.Location = new Point(134, 75);
            txtMaPhieu.Name = "txtMaPhieu";
            txtMaPhieu.Size = new Size(122, 23);
            txtMaPhieu.TabIndex = 4;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(16, 83);
            label4.Name = "label4";
            label4.Size = new Size(57, 15);
            label4.TabIndex = 3;
            label4.Text = "Mã Phiếu";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(16, 131);
            label3.Name = "label3";
            label3.Size = new Size(79, 15);
            label3.TabIndex = 2;
            label3.Text = "Mã nhân viên";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(16, 37);
            label2.Name = "label2";
            label2.Size = new Size(46, 15);
            label2.TabIndex = 1;
            label2.Text = "Mã Thẻ";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 25F);
            label1.Location = new Point(237, 23);
            label1.Name = "label1";
            label1.Size = new Size(385, 46);
            label1.TabIndex = 18;
            label1.Text = "Quản Lý Phiếu Bán Hàng";
            // 
            // button1
            // 
            button1.BackColor = Color.Red;
            button1.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            button1.ForeColor = Color.White;
            button1.Location = new Point(12, 23);
            button1.Name = "button1";
            button1.Size = new Size(156, 35);
            button1.TabIndex = 17;
            button1.Text = "Trờ về Menu ";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(dvgDanhSachPhieu);
            groupBox1.Location = new Point(403, 94);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(470, 333);
            groupBox1.TabIndex = 15;
            groupBox1.TabStop = false;
            groupBox1.Text = "Danh sách phiếu";
            // 
            // dvgDanhSachPhieu
            // 
            dvgDanhSachPhieu.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dvgDanhSachPhieu.Location = new Point(6, 22);
            dvgDanhSachPhieu.Name = "dvgDanhSachPhieu";
            dvgDanhSachPhieu.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dvgDanhSachPhieu.Size = new Size(457, 305);
            dvgDanhSachPhieu.TabIndex = 0;
            dvgDanhSachPhieu.CellClick += dataGridView1_CellClick;
            dvgDanhSachPhieu.CellDoubleClick += dataGridView1_CellDoubleClick;
            // 
            // QuanLyPhieuBanHang
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 192, 128);
            ClientSize = new Size(885, 450);
            Controls.Add(groupBox2);
            Controls.Add(label1);
            Controls.Add(button1);
            Controls.Add(groupBox1);
            Name = "QuanLyPhieuBanHang";
            Text = "QuanLyPhieuBanHang";
            Load += QuanLyPhieuBanHang_Load_1;
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dvgDanhSachPhieu).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox groupBox2;
        private Button btnXoaPhieu;
        private Button btnSuaPhieu;
        private Button btnThemPhieu;
        private RadioButton rdbPaid;
        private RadioButton rdbConfirmation;
        private TextBox textBox4;
        private Label label6;
        private Label label5;
        private TextBox textBox3;
        private TextBox txtMaPhieu;
        private Label label4;
        private Label label3;
        private Label label2;
        private TextBox textBox1;
        private Label label1;
        private Button button1;
        private GroupBox groupBox1;
        private DataGridView dvgDanhSachPhieu;
        private DateTimePicker dtpNgayTao;
        private ComboBox cboNhanVienBH;
        private ComboBox cboMaTheLuuDong;
        private Button btnMoiPhieu;
    }
}