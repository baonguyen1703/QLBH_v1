﻿namespace GUI
{
    partial class DoiMatKhau
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pictureBox3 = new PictureBox();
            pictureBox2 = new PictureBox();
            pictureBox1 = new PictureBox();
            button1 = new Button();
            button2 = new Button();
            txtMatKhauCu = new TextBox();
            txtMatKhauMoi = new TextBox();
            txtXacNhanMatKhau = new TextBox();
            txtHoTen = new TextBox();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            txtMaNhanVien = new TextBox();
            chkMatKhauCu = new CheckBox();
            chkMatKhauMoi = new CheckBox();
            chkXacNhanMauKhau = new CheckBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // pictureBox3
            // 
            pictureBox3.Image = Properties.Resources.neymar;
            pictureBox3.Location = new Point(655, 168);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(100, 120);
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox3.TabIndex = 46;
            pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources._7ta;
            pictureBox2.Location = new Point(655, 318);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(100, 120);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 45;
            pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.messi;
            pictureBox1.Location = new Point(655, 32);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(100, 120);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 44;
            pictureBox1.TabStop = false;
            // 
            // button1
            // 
            button1.BackColor = Color.Red;
            button1.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            button1.ForeColor = Color.White;
            button1.Location = new Point(46, 12);
            button1.Name = "button1";
            button1.Size = new Size(156, 35);
            button1.TabIndex = 43;
            button1.Text = "Trờ về Menu";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.Blue;
            button2.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            button2.ForeColor = Color.White;
            button2.Location = new Point(336, 355);
            button2.Name = "button2";
            button2.Size = new Size(84, 35);
            button2.TabIndex = 42;
            button2.Text = "Đổi";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // txtMatKhauCu
            // 
            txtMatKhauCu.Location = new Point(217, 221);
            txtMatKhauCu.Name = "txtMatKhauCu";
            txtMatKhauCu.Size = new Size(326, 23);
            txtMatKhauCu.TabIndex = 41;
            txtMatKhauCu.TextChanged += textBox5_TextChanged;
            // 
            // txtMatKhauMoi
            // 
            txtMatKhauMoi.Location = new Point(218, 262);
            txtMatKhauMoi.Name = "txtMatKhauMoi";
            txtMatKhauMoi.Size = new Size(326, 23);
            txtMatKhauMoi.TabIndex = 40;
            // 
            // txtXacNhanMatKhau
            // 
            txtXacNhanMatKhau.Location = new Point(217, 306);
            txtXacNhanMatKhau.Name = "txtXacNhanMatKhau";
            txtXacNhanMatKhau.Size = new Size(326, 23);
            txtXacNhanMatKhau.TabIndex = 39;
            txtXacNhanMatKhau.TextChanged += textBox3_TextChanged;
            // 
            // txtHoTen
            // 
            txtHoTen.Location = new Point(217, 182);
            txtHoTen.Name = "txtHoTen";
            txtHoTen.Size = new Size(326, 23);
            txtHoTen.TabIndex = 38;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(79, 309);
            label6.Name = "label6";
            label6.Size = new Size(109, 15);
            label6.TabIndex = 37;
            label6.Text = "Xác nhận mật khẩu";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(79, 265);
            label5.Name = "label5";
            label5.Size = new Size(81, 15);
            label5.TabIndex = 36;
            label5.Text = "Mật khẩu mới";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(79, 224);
            label4.Name = "label4";
            label4.Size = new Size(73, 15);
            label4.TabIndex = 35;
            label4.Text = "Mật khẩu cũ";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(81, 190);
            label3.Name = "label3";
            label3.Size = new Size(80, 15);
            label3.TabIndex = 34;
            label3.Text = "Tên nhân viên";
            label3.Click += label3_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(81, 151);
            label2.Name = "label2";
            label2.Size = new Size(79, 15);
            label2.TabIndex = 33;
            label2.Text = "Mã nhân viên";
            label2.Click += label2_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 30F, FontStyle.Bold);
            label1.Location = new Point(280, 46);
            label1.Name = "label1";
            label1.Size = new Size(277, 54);
            label1.TabIndex = 32;
            label1.Text = "Đổi mật khẩu";
            label1.Click += label1_Click_1;
            // 
            // txtMaNhanVien
            // 
            txtMaNhanVien.Location = new Point(218, 143);
            txtMaNhanVien.Name = "txtMaNhanVien";
            txtMaNhanVien.Size = new Size(326, 23);
            txtMaNhanVien.TabIndex = 31;
            // 
            // chkMatKhauCu
            // 
            chkMatKhauCu.AutoSize = true;
            chkMatKhauCu.Location = new Point(549, 225);
            chkMatKhauCu.Name = "chkMatKhauCu";
            chkMatKhauCu.Size = new Size(105, 19);
            chkMatKhauCu.TabIndex = 47;
            chkMatKhauCu.Text = "Hiện Mật Khẩu";
            chkMatKhauCu.UseVisualStyleBackColor = true;
            chkMatKhauCu.CheckedChanged += chkMatKhauCu_CheckedChanged;
            // 
            // chkMatKhauMoi
            // 
            chkMatKhauMoi.AutoSize = true;
            chkMatKhauMoi.Location = new Point(550, 265);
            chkMatKhauMoi.Name = "chkMatKhauMoi";
            chkMatKhauMoi.Size = new Size(105, 19);
            chkMatKhauMoi.TabIndex = 48;
            chkMatKhauMoi.Text = "Hiện Mật Khẩu";
            chkMatKhauMoi.UseVisualStyleBackColor = true;
            chkMatKhauMoi.CheckedChanged += chkMatKhauMoi_CheckedChanged;
            // 
            // chkXacNhanMauKhau
            // 
            chkXacNhanMauKhau.AutoSize = true;
            chkXacNhanMauKhau.Location = new Point(550, 310);
            chkXacNhanMauKhau.Name = "chkXacNhanMauKhau";
            chkXacNhanMauKhau.Size = new Size(105, 19);
            chkXacNhanMauKhau.TabIndex = 49;
            chkXacNhanMauKhau.Text = "Hiện Mật Khẩu";
            chkXacNhanMauKhau.UseVisualStyleBackColor = true;
            chkXacNhanMauKhau.CheckedChanged += chkXacNhanMauKhau_CheckedChanged;
            // 
            // DoiMatKhau
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 192, 128);
            ClientSize = new Size(800, 450);
            Controls.Add(chkXacNhanMauKhau);
            Controls.Add(chkMatKhauMoi);
            Controls.Add(chkMatKhauCu);
            Controls.Add(pictureBox3);
            Controls.Add(pictureBox2);
            Controls.Add(pictureBox1);
            Controls.Add(button1);
            Controls.Add(button2);
            Controls.Add(txtMatKhauCu);
            Controls.Add(txtMatKhauMoi);
            Controls.Add(txtXacNhanMatKhau);
            Controls.Add(txtHoTen);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtMaNhanVien);
            Name = "DoiMatKhau";
            Text = "DoiMatKhau";
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox3;
        private PictureBox pictureBox2;
        private PictureBox pictureBox1;
        private Button button1;
        private Button button2;
        private TextBox txtMatKhauCu;
        private TextBox txtMatKhauMoi;
        private TextBox txtXacNhanMatKhau;
        private TextBox txtHoTen;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox txtMaNhanVien;
        private CheckBox chkMatKhauCu;
        private CheckBox chkMatKhauMoi;
        private CheckBox chkXacNhanMauKhau;
    }
}