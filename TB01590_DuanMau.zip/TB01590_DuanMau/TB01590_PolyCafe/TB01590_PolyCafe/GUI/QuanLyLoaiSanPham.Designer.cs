﻿namespace GUI
{
    partial class QuanLyLoaiSanPham
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox2 = new GroupBox();
            button5 = new Button();
            pictureBox2 = new PictureBox();
            btnXoaLoaiSP = new Button();
            btnSuaLoaiSP = new Button();
            btnThemLoaiSP = new Button();
            txtGhiChuSP = new TextBox();
            txtTenLoaiSP = new TextBox();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            txtMaLoaiSP = new TextBox();
            label1 = new Label();
            button1 = new Button();
            groupBox1 = new GroupBox();
            dataGridView1 = new DataGridView();
            groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(button5);
            groupBox2.Controls.Add(pictureBox2);
            groupBox2.Controls.Add(btnXoaLoaiSP);
            groupBox2.Controls.Add(btnSuaLoaiSP);
            groupBox2.Controls.Add(btnThemLoaiSP);
            groupBox2.Controls.Add(txtGhiChuSP);
            groupBox2.Controls.Add(txtTenLoaiSP);
            groupBox2.Controls.Add(label4);
            groupBox2.Controls.Add(label3);
            groupBox2.Controls.Add(label2);
            groupBox2.Controls.Add(txtMaLoaiSP);
            groupBox2.Location = new Point(12, 81);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(294, 359);
            groupBox2.TabIndex = 8;
            groupBox2.TabStop = false;
            groupBox2.Text = "Thông tin";
            groupBox2.Enter += groupBox2_Enter;
            // 
            // button5
            // 
            button5.Image = Properties.Resources.up_to_date3;
            button5.ImageAlign = ContentAlignment.MiddleLeft;
            button5.Location = new Point(110, 311);
            button5.Name = "button5";
            button5.Size = new Size(98, 42);
            button5.TabIndex = 10;
            button5.Text = "Mới";
            button5.TextAlign = ContentAlignment.MiddleRight;
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.coffee;
            pictureBox2.Location = new Point(67, 22);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(150, 108);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 9;
            pictureBox2.TabStop = false;
            // 
            // btnXoaLoaiSP
            // 
            btnXoaLoaiSP.Image = Properties.Resources.delete;
            btnXoaLoaiSP.ImageAlign = ContentAlignment.MiddleLeft;
            btnXoaLoaiSP.Location = new Point(16, 311);
            btnXoaLoaiSP.Name = "btnXoaLoaiSP";
            btnXoaLoaiSP.Size = new Size(73, 42);
            btnXoaLoaiSP.TabIndex = 8;
            btnXoaLoaiSP.Text = "Xóa";
            btnXoaLoaiSP.TextAlign = ContentAlignment.MiddleRight;
            btnXoaLoaiSP.UseVisualStyleBackColor = true;
            btnXoaLoaiSP.Click += btnXoaLoaiSP_Click;
            // 
            // btnSuaLoaiSP
            // 
            btnSuaLoaiSP.Image = Properties.Resources.pen;
            btnSuaLoaiSP.ImageAlign = ContentAlignment.MiddleLeft;
            btnSuaLoaiSP.Location = new Point(110, 257);
            btnSuaLoaiSP.Name = "btnSuaLoaiSP";
            btnSuaLoaiSP.Size = new Size(98, 42);
            btnSuaLoaiSP.TabIndex = 7;
            btnSuaLoaiSP.Text = "Cập nhật";
            btnSuaLoaiSP.TextAlign = ContentAlignment.MiddleRight;
            btnSuaLoaiSP.UseVisualStyleBackColor = true;
            btnSuaLoaiSP.Click += btnSuaLoaiSP_Click;
            // 
            // btnThemLoaiSP
            // 
            btnThemLoaiSP.Image = Properties.Resources.plus;
            btnThemLoaiSP.ImageAlign = ContentAlignment.MiddleLeft;
            btnThemLoaiSP.Location = new Point(17, 257);
            btnThemLoaiSP.Name = "btnThemLoaiSP";
            btnThemLoaiSP.Size = new Size(74, 42);
            btnThemLoaiSP.TabIndex = 6;
            btnThemLoaiSP.Text = "Thêm";
            btnThemLoaiSP.TextAlign = ContentAlignment.MiddleRight;
            btnThemLoaiSP.UseVisualStyleBackColor = true;
            btnThemLoaiSP.Click += btnThemLoaiSP_Click;
            // 
            // txtGhiChuSP
            // 
            txtGhiChuSP.Location = new Point(96, 218);
            txtGhiChuSP.Name = "txtGhiChuSP";
            txtGhiChuSP.Size = new Size(173, 23);
            txtGhiChuSP.TabIndex = 5;
            // 
            // txtTenLoaiSP
            // 
            txtTenLoaiSP.Location = new Point(96, 182);
            txtTenLoaiSP.Name = "txtTenLoaiSP";
            txtTenLoaiSP.Size = new Size(173, 23);
            txtTenLoaiSP.TabIndex = 4;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(16, 221);
            label4.Name = "label4";
            label4.Size = new Size(48, 15);
            label4.TabIndex = 3;
            label4.Text = "Ghi chú";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(17, 185);
            label3.Name = "label3";
            label3.Size = new Size(47, 15);
            label3.TabIndex = 2;
            label3.Text = "Tên loại";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(18, 148);
            label2.Name = "label2";
            label2.Size = new Size(46, 15);
            label2.TabIndex = 1;
            label2.Text = "Mã loại";
            // 
            // txtMaLoaiSP
            // 
            txtMaLoaiSP.Location = new Point(96, 148);
            txtMaLoaiSP.Name = "txtMaLoaiSP";
            txtMaLoaiSP.Size = new Size(173, 23);
            txtMaLoaiSP.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 25F);
            label1.Location = new Point(207, 10);
            label1.Name = "label1";
            label1.Size = new Size(366, 46);
            label1.TabIndex = 10;
            label1.Text = "Quản Lý Loại Sản Phẩm";
            // 
            // button1
            // 
            button1.BackColor = Color.Red;
            button1.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            button1.ForeColor = Color.White;
            button1.Location = new Point(12, 14);
            button1.Name = "button1";
            button1.Size = new Size(156, 35);
            button1.TabIndex = 9;
            button1.Text = "Trờ về Menu";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(dataGridView1);
            groupBox1.Location = new Point(312, 81);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(596, 359);
            groupBox1.TabIndex = 7;
            groupBox1.TabStop = false;
            groupBox1.Text = "Loại sản phẩm";
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(6, 22);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(584, 331);
            dataGridView1.TabIndex = 0;
            dataGridView1.CellDoubleClick += dataGridView1_CellDoubleClick;
            // 
            // QuanLyLoaiSanPham
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 192, 128);
            ClientSize = new Size(920, 450);
            Controls.Add(groupBox2);
            Controls.Add(label1);
            Controls.Add(button1);
            Controls.Add(groupBox1);
            Name = "QuanLyLoaiSanPham";
            Text = "QuanLyLoaiSanPham";
            Load += QuanLyLoaiSanPham_Load_1;
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox groupBox2;
        private PictureBox pictureBox1;
        private Button btnXoaLoaiSP;
        private Button btnSuaLoaiSP;
        private Button btnThemLoaiSP;
        private TextBox txtGhiChuSP;
        private TextBox txtTenLoaiSP;
        private Label label4;
        private Label label3;
        private Label label2;
        private TextBox txtMaLoaiSP;
        private Label label1;
        private Button button1;
        private GroupBox groupBox1;
        private DataGridView dataGridView1;
        private PictureBox pictureBox2;
        private Button button5;
    }
}