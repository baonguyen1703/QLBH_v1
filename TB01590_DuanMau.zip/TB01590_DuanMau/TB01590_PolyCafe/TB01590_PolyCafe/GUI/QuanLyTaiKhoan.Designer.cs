﻿namespace GUI
{
    partial class QuanLyTaiKhoan
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox2 = new GroupBox();
            btnMoi = new Button();
            txtMatKhau = new TextBox();
            label6 = new Label();
            btnXoa = new Button();
            btnSua = new Button();
            btnThem = new Button();
            txtEmail = new TextBox();
            txtHoTen = new TextBox();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            txtMaNhanVien = new TextBox();
            groupBox3 = new GroupBox();
            rbNhanVien = new RadioButton();
            rbQuanLy = new RadioButton();
            groupBox4 = new GroupBox();
            rbNgungHoatDong = new RadioButton();
            rbConHoatDong = new RadioButton();
            label1 = new Label();
            button1 = new Button();
            groupBox1 = new GroupBox();
            textBox6 = new TextBox();
            button5 = new Button();
            dgvDanhSachNV = new DataGridView();
            groupBox2.SuspendLayout();
            groupBox3.SuspendLayout();
            groupBox4.SuspendLayout();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvDanhSachNV).BeginInit();
            SuspendLayout();
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(btnMoi);
            groupBox2.Controls.Add(txtMatKhau);
            groupBox2.Controls.Add(label6);
            groupBox2.Controls.Add(btnXoa);
            groupBox2.Controls.Add(btnSua);
            groupBox2.Controls.Add(btnThem);
            groupBox2.Controls.Add(txtEmail);
            groupBox2.Controls.Add(txtHoTen);
            groupBox2.Controls.Add(label4);
            groupBox2.Controls.Add(label3);
            groupBox2.Controls.Add(label2);
            groupBox2.Controls.Add(txtMaNhanVien);
            groupBox2.Controls.Add(groupBox3);
            groupBox2.Controls.Add(groupBox4);
            groupBox2.Location = new Point(16, 59);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(285, 393);
            groupBox2.TabIndex = 20;
            groupBox2.TabStop = false;
            groupBox2.Text = "Thông tin";
            // 
            // btnMoi
            // 
            btnMoi.Image = Properties.Resources.up_to_date;
            btnMoi.ImageAlign = ContentAlignment.MiddleLeft;
            btnMoi.Location = new Point(171, 338);
            btnMoi.Name = "btnMoi";
            btnMoi.Size = new Size(69, 37);
            btnMoi.TabIndex = 22;
            btnMoi.Text = "Mới";
            btnMoi.TextAlign = ContentAlignment.MiddleRight;
            btnMoi.UseVisualStyleBackColor = true;
            btnMoi.Click += btnMoi_Click;
            // 
            // txtMatKhau
            // 
            txtMatKhau.Location = new Point(98, 120);
            txtMatKhau.Name = "txtMatKhau";
            txtMatKhau.Size = new Size(158, 23);
            txtMatKhau.TabIndex = 11;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(9, 120);
            label6.Name = "label6";
            label6.Size = new Size(57, 15);
            label6.TabIndex = 10;
            label6.Text = "Mật khẩu";
            // 
            // btnXoa
            // 
            btnXoa.Image = Properties.Resources.delete;
            btnXoa.ImageAlign = ContentAlignment.MiddleLeft;
            btnXoa.Location = new Point(45, 336);
            btnXoa.Name = "btnXoa";
            btnXoa.Size = new Size(75, 39);
            btnXoa.TabIndex = 8;
            btnXoa.Text = "Xóa";
            btnXoa.TextAlign = ContentAlignment.MiddleRight;
            btnXoa.UseVisualStyleBackColor = true;
            btnXoa.Click += btnXoa_Click;
            // 
            // btnSua
            // 
            btnSua.Image = Properties.Resources.pen1;
            btnSua.ImageAlign = ContentAlignment.MiddleLeft;
            btnSua.Location = new Point(171, 293);
            btnSua.Name = "btnSua";
            btnSua.Size = new Size(69, 39);
            btnSua.TabIndex = 7;
            btnSua.Text = "Sửa";
            btnSua.TextAlign = ContentAlignment.MiddleRight;
            btnSua.UseVisualStyleBackColor = true;
            btnSua.Click += btnSua_Click;
            // 
            // btnThem
            // 
            btnThem.Image = Properties.Resources.plus1;
            btnThem.ImageAlign = ContentAlignment.MiddleLeft;
            btnThem.Location = new Point(45, 293);
            btnThem.Name = "btnThem";
            btnThem.Size = new Size(76, 39);
            btnThem.TabIndex = 6;
            btnThem.Text = "Thêm";
            btnThem.TextAlign = ContentAlignment.MiddleRight;
            btnThem.UseVisualStyleBackColor = true;
            btnThem.Click += btnThem_Click;
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(98, 89);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(158, 23);
            txtEmail.TabIndex = 5;
            // 
            // txtHoTen
            // 
            txtHoTen.Location = new Point(98, 58);
            txtHoTen.Name = "txtHoTen";
            txtHoTen.Size = new Size(158, 23);
            txtHoTen.TabIndex = 4;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(9, 89);
            label4.Name = "label4";
            label4.Size = new Size(36, 15);
            label4.TabIndex = 3;
            label4.Text = "Email";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(9, 58);
            label3.Name = "label3";
            label3.Size = new Size(43, 15);
            label3.TabIndex = 2;
            label3.Text = "Họ tên";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(6, 28);
            label2.Name = "label2";
            label2.Size = new Size(79, 15);
            label2.TabIndex = 1;
            label2.Text = "Mã nhân viên";
            // 
            // txtMaNhanVien
            // 
            txtMaNhanVien.Location = new Point(98, 22);
            txtMaNhanVien.Name = "txtMaNhanVien";
            txtMaNhanVien.Size = new Size(158, 23);
            txtMaNhanVien.TabIndex = 0;
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(rbNhanVien);
            groupBox3.Controls.Add(rbQuanLy);
            groupBox3.Location = new Point(17, 149);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(239, 63);
            groupBox3.TabIndex = 21;
            groupBox3.TabStop = false;
            groupBox3.Text = "Vai Trò";
            // 
            // rbNhanVien
            // 
            rbNhanVien.AutoSize = true;
            rbNhanVien.Location = new Point(130, 25);
            rbNhanVien.Name = "rbNhanVien";
            rbNhanVien.Size = new Size(79, 19);
            rbNhanVien.TabIndex = 20;
            rbNhanVien.Text = "Nhân viên";
            rbNhanVien.UseVisualStyleBackColor = true;
            // 
            // rbQuanLy
            // 
            rbQuanLy.AutoSize = true;
            rbQuanLy.Location = new Point(8, 25);
            rbQuanLy.Name = "rbQuanLy";
            rbQuanLy.Size = new Size(68, 19);
            rbQuanLy.TabIndex = 19;
            rbQuanLy.Text = "Quản Lý";
            rbQuanLy.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            groupBox4.Controls.Add(rbNgungHoatDong);
            groupBox4.Controls.Add(rbConHoatDong);
            groupBox4.Location = new Point(17, 218);
            groupBox4.Name = "groupBox4";
            groupBox4.Size = new Size(239, 63);
            groupBox4.TabIndex = 0;
            groupBox4.TabStop = false;
            groupBox4.Text = "Trạng Thái";
            // 
            // rbNgungHoatDong
            // 
            rbNgungHoatDong.AutoSize = true;
            rbNgungHoatDong.Location = new Point(119, 22);
            rbNgungHoatDong.Name = "rbNgungHoatDong";
            rbNgungHoatDong.Size = new Size(120, 19);
            rbNgungHoatDong.TabIndex = 18;
            rbNgungHoatDong.Text = "Ngừng hoạt động";
            rbNgungHoatDong.UseVisualStyleBackColor = true;
            // 
            // rbConHoatDong
            // 
            rbConHoatDong.AutoSize = true;
            rbConHoatDong.Location = new Point(8, 22);
            rbConHoatDong.Name = "rbConHoatDong";
            rbConHoatDong.Size = new Size(83, 19);
            rbConHoatDong.TabIndex = 17;
            rbConHoatDong.Text = "Hoạt Động";
            rbConHoatDong.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 25F);
            label1.Location = new Point(296, 10);
            label1.Name = "label1";
            label1.Size = new Size(292, 46);
            label1.TabIndex = 22;
            label1.Text = "Quản Lý Tài Khoản";
            // 
            // button1
            // 
            button1.BackColor = Color.Red;
            button1.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            button1.ForeColor = Color.White;
            button1.Location = new Point(9, 10);
            button1.Name = "button1";
            button1.Size = new Size(156, 35);
            button1.TabIndex = 21;
            button1.Text = "Trờ về Menu";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(textBox6);
            groupBox1.Controls.Add(button5);
            groupBox1.Controls.Add(dgvDanhSachNV);
            groupBox1.Location = new Point(307, 59);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(687, 393);
            groupBox1.TabIndex = 19;
            groupBox1.TabStop = false;
            groupBox1.Text = "Danh sách phiếu";
            // 
            // textBox6
            // 
            textBox6.Location = new Point(455, 20);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(133, 23);
            textBox6.TabIndex = 21;
            // 
            // button5
            // 
            button5.Location = new Point(594, 21);
            button5.Name = "button5";
            button5.Size = new Size(75, 23);
            button5.TabIndex = 22;
            button5.Text = "Tìm";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // dgvDanhSachNV
            // 
            dgvDanhSachNV.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvDanhSachNV.Dock = DockStyle.Fill;
            dgvDanhSachNV.Location = new Point(3, 19);
            dgvDanhSachNV.Name = "dgvDanhSachNV";
            dgvDanhSachNV.Size = new Size(681, 371);
            dgvDanhSachNV.TabIndex = 0;
            dgvDanhSachNV.CellContentClick += dgvDanhSachNV_CellContentClick;
            // 
            // QuanLyTaiKhoan
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 192, 128);
            ClientSize = new Size(1008, 464);
            Controls.Add(groupBox2);
            Controls.Add(label1);
            Controls.Add(button1);
            Controls.Add(groupBox1);
            Name = "QuanLyTaiKhoan";
            Text = "QuanLyTaiKhoan";
            Load += QuanLyTaiKhoan_Load;
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            groupBox4.ResumeLayout(false);
            groupBox4.PerformLayout();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvDanhSachNV).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox groupBox2;
        private TextBox txtMatKhau;
        private Label label6;
        private Button btnXoa;
        private Button btnSua;
        private Button btnThem;
        private TextBox txtEmail;
        private TextBox txtHoTen;
        private Label label4;
        private Label label3;
        private Label label2;
        private TextBox txtMaNhanVien;
        private Label label1;
        private Button button1;
        private GroupBox groupBox1;
        private DataGridView dgvDanhSachNV;
        private RadioButton rbNgungHoatDong;
        private RadioButton rbConHoatDong;
        private RadioButton rbNhanVien;
        private RadioButton rbQuanLy;
        private Button button5;
        private TextBox textBox6;
        private GroupBox groupBox3;
        private GroupBox groupBox4;
        private Button btnMoi;
    }
}