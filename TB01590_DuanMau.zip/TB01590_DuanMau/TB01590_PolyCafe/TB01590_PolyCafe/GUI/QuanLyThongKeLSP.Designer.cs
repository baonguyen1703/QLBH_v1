﻿namespace GUI
{
    partial class QuanLyThongKeLSP
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox2 = new GroupBox();
            dgrDanhSachThongKe = new DataGridView();
            groupBox1 = new GroupBox();
            cbxLoaiSanPham = new ComboBox();
            btnThongKe = new Button();
            label5 = new Label();
            label3 = new Label();
            dtpDenNgay = new DateTimePicker();
            dtpTuNgay = new DateTimePicker();
            label4 = new Label();
            label2 = new Label();
            button1 = new Button();
            label1 = new Label();
            groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgrDanhSachThongKe).BeginInit();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(dgrDanhSachThongKe);
            groupBox2.Location = new Point(12, 195);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(776, 244);
            groupBox2.TabIndex = 26;
            groupBox2.TabStop = false;
            groupBox2.Text = "Danh sách";
            // 
            // dgrDanhSachThongKe
            // 
            dgrDanhSachThongKe.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgrDanhSachThongKe.Location = new Point(6, 22);
            dgrDanhSachThongKe.Name = "dgrDanhSachThongKe";
            dgrDanhSachThongKe.Size = new Size(764, 215);
            dgrDanhSachThongKe.TabIndex = 0;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(cbxLoaiSanPham);
            groupBox1.Controls.Add(btnThongKe);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(dtpDenNgay);
            groupBox1.Controls.Add(dtpTuNgay);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(label2);
            groupBox1.Location = new Point(12, 98);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(776, 91);
            groupBox1.TabIndex = 25;
            groupBox1.TabStop = false;
            groupBox1.Text = "Thông tin thống kê";
            // 
            // cbxLoaiSanPham
            // 
            cbxLoaiSanPham.FormattingEnabled = true;
            cbxLoaiSanPham.Location = new Point(96, 25);
            cbxLoaiSanPham.Name = "cbxLoaiSanPham";
            cbxLoaiSanPham.Size = new Size(121, 23);
            cbxLoaiSanPham.TabIndex = 20;
            // 
            // btnThongKe
            // 
            btnThongKe.BackColor = Color.Blue;
            btnThongKe.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            btnThongKe.ForeColor = SystemColors.ControlLightLight;
            btnThongKe.Location = new Point(6, 56);
            btnThongKe.Name = "btnThongKe";
            btnThongKe.Size = new Size(97, 28);
            btnThongKe.TabIndex = 18;
            btnThongKe.Text = "Thống kê";
            btnThongKe.UseVisualStyleBackColor = false;
            btnThongKe.Click += btnThongKe_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(507, 26);
            label5.Name = "label5";
            label5.Size = new Size(57, 15);
            label5.TabIndex = 7;
            label5.Text = "Đến ngày";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(246, 28);
            label3.Name = "label3";
            label3.Size = new Size(49, 15);
            label3.TabIndex = 6;
            label3.Text = "Từ ngày";
            // 
            // dtpDenNgay
            // 
            dtpDenNgay.Location = new Point(570, 20);
            dtpDenNgay.Name = "dtpDenNgay";
            dtpDenNgay.Size = new Size(200, 23);
            dtpDenNgay.TabIndex = 5;
            // 
            // dtpTuNgay
            // 
            dtpTuNgay.Location = new Point(301, 20);
            dtpTuNgay.Name = "dtpTuNgay";
            dtpTuNgay.Size = new Size(200, 23);
            dtpTuNgay.TabIndex = 4;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(-65, -85);
            label4.Name = "label4";
            label4.Size = new Size(49, 15);
            label4.TabIndex = 3;
            label4.Text = "Từ ngày";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(6, 28);
            label2.Name = "label2";
            label2.Size = new Size(84, 15);
            label2.TabIndex = 0;
            label2.Text = "Loại sản phẩm";
            // 
            // button1
            // 
            button1.BackColor = Color.Red;
            button1.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            button1.ForeColor = SystemColors.ControlLightLight;
            button1.Location = new Point(12, 12);
            button1.Name = "button1";
            button1.Size = new Size(156, 35);
            button1.TabIndex = 24;
            button1.Text = "Trờ về Menu";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 25F);
            label1.Location = new Point(142, 49);
            label1.Name = "label1";
            label1.Size = new Size(646, 46);
            label1.TabIndex = 23;
            label1.Text = "Thống Kê Doanh Thu Theo Loại Sản Phẩm";
            // 
            // QuanLyThongKeLSP
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 192, 128);
            ClientSize = new Size(800, 450);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Controls.Add(button1);
            Controls.Add(label1);
            Name = "QuanLyThongKeLSP";
            Text = "QuanLyThongKeLSP";
            Load += QuanLyThongKeLSP_Load;
            groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgrDanhSachThongKe).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox groupBox2;
        private DataGridView dgrDanhSachThongKe;
        private GroupBox groupBox1;
        private Button btnThongKe;
        private Label label5;
        private Label label3;
        private DateTimePicker dtpDenNgay;
        private DateTimePicker dtpTuNgay;
        private Label label4;
        private Label label2;
        private Button button1;
        private Label label1;
        private ComboBox cbxLoaiSanPham;
    }
}