﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DAL;
using UTIL;

namespace GUI
{
    public partial class DoiMatKhau : Form
    {
        DALNhanVien dALNhanVien = new DALNhanVien();
        public DoiMatKhau()
        {
            InitializeComponent();
        }



        private void DoiMatKhau_Load(object sender, EventArgs e)
        {
            if (AuthUtil.IsLogin())
            {
                txtMaNhanVien.Text = AuthUtil.user.MaNhanVien;
                txtHoTen.Text = AuthUtil.user.HoTen;
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void chkMatKhauCu_CheckedChanged(object sender, EventArgs e)
        {
            txtMatKhauCu.PasswordChar = chkMatKhauCu.Checked ? '\0' : '*';
        }

        private void chkMatKhauMoi_CheckedChanged(object sender, EventArgs e)
        {
            txtMatKhauMoi.PasswordChar = chkMatKhauMoi.Checked ? '\0' : '*';
        }

        private void chkXacNhanMauKhau_CheckedChanged(object sender, EventArgs e)
        {
            txtXacNhanMatKhau.PasswordChar = chkXacNhanMauKhau.Checked ? '\0' : '*';
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (!AuthUtil.user.MatKhau.Equals(txtMatKhauCu.Text))
            {
                MessageBox.Show(this, "Mật khẩu cũ chưa đúng");
            }
            else
            {
                if (!txtMatKhauMoi.Text.Equals(txtXacNhanMatKhau.Text))
                {
                    MessageBox.Show(this, "Xác nhận mật khẩu mới chưa trùng khớp");
                }
                else
                {
                    AuthUtil.user.MatKhau = txtMatKhauMoi.Text;
                    dALNhanVien.updateNhanVien(AuthUtil.user);
                    MessageBox.Show(this, "Đổi mật khẩu thành công");
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
