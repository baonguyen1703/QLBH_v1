﻿namespace DTO
{
    public class Class1
    {

    }
}
