﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class TKDoanhThuLoaiSP
    {
        public string? MaSanPham { get; set; }
        public string? TenSanPham { get; set; }
        public int SoLy { get; set; }
        public int SoLuongPhieu { get; set; }
        public string NgayBan { get; set; }
        public string TongTien { get; set; }
        public string DaThanhToan { get; set; }
    }
}
